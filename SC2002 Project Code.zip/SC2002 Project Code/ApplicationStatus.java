public enum ApplicationStatus {
	PENDING,
    SUCCESSFUL,
    UNSUCCESSFUL,
    WITHDRAWN,
    WITHDRAW_REQUESTED,   
    CONFIRMED             
}
