public enum OpportunityStatus {
    PENDING_APPROVAL,
    APPROVED,
    REJECTED,
    FILLED
}
