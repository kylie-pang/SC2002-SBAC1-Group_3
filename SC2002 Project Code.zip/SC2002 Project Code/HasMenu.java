public interface HasMenu {
    void displayMenu();
}
