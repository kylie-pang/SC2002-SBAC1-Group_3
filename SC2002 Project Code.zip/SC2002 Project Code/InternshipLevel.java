public enum InternshipLevel {
    BASIC,
    INTERMEDIATE,
    ADVANCED
}
